grant all on *.* to 'vagrant'@'%' identified by 'secret';
